--> Sql uygulama s�nav�;

use kitapci
-->b
create procedure st1
as
 begin
  select Kategoriler.Aciklamalar,count(Kitaplar.KitapNo) as 'Say�s�:' from Kitaplar
  inner join Kategoriler on Kategoriler.KategoriNo=Kitaplar.KategoriNo
  inner join KiraDetaylari on KiraDetaylari.KitapNo=Kitaplar.KitapNo
  inner join Kiralar on Kiralar.FaturaNo=KiraDetaylari.FaturaNo
  where year(Kiralar.KiralamaTarihi)<=2011
  group by Kategoriler.Aciklamalar
 end

 exec st1

 -->c
 create function f1(@kno int)
 returns table
 as
  return(
   select Kitaplar.KitapAdi,Kategoriler.Aciklamalar,Kitaplar.Rating,Kitaplar.KiralamaFiyat,
   Kiralar.KiralamaTarihi,Kiralar.TeslimTarihi,Musteriler.MusteriAdi from Kitaplar
   inner join Kategoriler on Kategoriler.KategoriNo=Kitaplar.KategoriNo
   inner join KiraDetaylari on KiraDetaylari.KitapNo=Kitaplar.KitapNo
   inner join Kiralar on Kiralar.FaturaNo=KiraDetaylari.FaturaNo
   inner join Musteriler on Musteriler.MusteriNo=Kiralar.MusteriNo
   where Kitaplar.KitapNo=@kno
  )
select * from f1(2)

-->d
create function fd()
returns @gg table(madi varchar(35),kadi varchar(35),sayi int)
as
 begin
  insert into @gg
  select Musteriler.MusteriAdi,Kategoriler.Aciklamalar,count(Kitaplar.KitapNo) as 'Say�s�: ' from Kitaplar
  inner join Kategoriler on Kategoriler.KategoriNo=Kitaplar.KategoriNo
  inner join KiraDetaylari on KiraDetaylari.KitapNo=Kitaplar.KitapNo
  inner join Kiralar on Kiralar.FaturaNo=KiraDetaylari.FaturaNo
  inner join Musteriler on Musteriler.MusteriNo=Kiralar.MusteriNo
  group by Kategoriler.Aciklamalar,Musteriler.MusteriAdi
  return
 end

select * from fd()

-->e
declare @ee table(emadi varchar(35),emsadi varchar(35),emadres varchar(35),madi varchar(35),msadi varchar(35),madres varchar(35))

update Musteriler set MusteriAdi='M2',MusteriSoyadi='MS2',MusteriAdres='MAd2'
output deleted.MusteriAdi,deleted.MusteriSoyadi,deleted.MusteriAdres,inserted.MusteriAdi,inserted.MusteriSoyadi,inserted.MusteriAdres into @ee
where MusteriNo=2
select * from @ee

-->f
select Musteriler.MusteriAdi,sum(Kitaplar.KiralamaFiyat) as '�denen Toplam �cret: ' from Kitaplar
inner join KiraDetaylari on KiraDetaylari.KitapNo=Kitaplar.KitapNo
inner join Kiralar on Kiralar.FaturaNo=KiraDetaylari.FaturaNo
inner join Musteriler on Musteriler.MusteriNo=Kiralar.MusteriNo
group by Musteriler.MusteriNo,Musteriler.MusteriAdi