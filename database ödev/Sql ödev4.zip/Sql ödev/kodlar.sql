create database galeri
use galeri
create table arac(aracno int primary key,model varchar(30) ,marka varchar(30),plaka varchar(10),fiyat money)
create table musteri(mno int primary key,madi varchar(30),msoyadi varchar(30),madres varchar(30),mtel varchar(30))
create table satis(stno int primary key,mno int foreign key references musteri(mno),
		aracno int foreign key references arac(aracno),strh varchar(30),sfiyat money)
create table alim(alno int primary key,mno int foreign key references musteri(mno),aracno int foreign key references arac(aracno),altrh varchar(15),afiyat money)

insert into musteri values(1,'Turgut','�zseven','Turhal/Tokat','03562222222')
insert into musteri values(2,'Mustafa','�a�layan','Meram/Konya','05112111111')
insert into musteri values(3,'Ahmet','Kara','Zile/Tokat','03563333333')
insert into musteri values(4,'Murat','Beyaz','Turhal/Tokat','03565555555')
insert into musteri values(5,'Elif','Kurt','Be�ikta�/�stanbul','057814714')
insert into musteri values(6,'Ay�e','U�ar','Ta�ova/Amasya','035866666')
insert into musteri values(7,'B�lent','Ayar','Turhal/Tokat','03568888888')

insert into arac values(1,'2004','Fiat Marea','60 TT 6060',16000)
insert into arac values(2,'2000','Renault Megane','60 TT 6061',14000)
insert into arac values(3,'2007','Ford Focus','60 TT 6062',28000)
insert into arac values(4,'2005','Volkswagen Golf','60 TT 6063',26000)
insert into arac values(5,'1998','Opel Astra','60 TT 6064',9000)

insert into satis values(1,1,1,'04.05.2010',17000)
insert into satis values(2,4,5,'01.06.2010',11500)
insert into satis values(3,7,4,'15.06.2010',27000)
insert into satis values(4,2,1,'02.07.2010',17500)

insert into alim values(1,3,1,'08.02.2010',15000)
insert into alim values(2,6,1,'12.04.2010',15500)
insert into alim values(3,2,5,'15.04.2010',9500)
insert into alim values(4,1,2,'15.05.2010',14000)
insert into alim values(5,5,3,'22.08.2010',26000)

--> Soru 1
declare @max_sat_fiy int
select @max_sat_fiy=MAX(satis.sfiyat) from satis,arac where arac.aracno=satis.aracno
print(CAST(@max_sat_fiy as varchar(20)))

-->Soru 3
select @@ERROR as 'Hata Kodu: ', @@IDENTITY as 'Tan�m�: '

-->Soru 4
declare @musteri table (ad varchar(25),soyad varchar(25))

insert into @musteri values ('Turgut','�zseven')
insert into @musteri values ('Mustafa','�a�layan')
insert into @musteri values ('Ahmet','Kara')
insert into @musteri values ('Murat','Beyaz')
insert into @musteri values ('Elif','Kurt')
insert into @musteri values ('Ay�e','U�ar')
insert into @musteri values ('B�lent','Ayar')

select * from @musteri

--> Soru 5
select * from satis where satis.aracno=3

if(@@ROWCOUNT>0)
begin
	select musteri.madi,musteri.msoyadi,arac.marka,satis.strh,satis.sfiyat from musteri,arac,satis where satis.aracno=arac.aracno and satis.mno=musteri.mno and satis.aracno=3
end
else
begin
	print('Bu ara�tan sat�� yap�lmam��t�r.')
end

-->Soru 6
declare @fy money
select @fy=arac.fiyat from arac where arac.model in (select MAX(arac.model) from arac)

while(@fy<=34000)
begin
	update arac set arac.fiyat+=arac.fiyat*0.1
	select @fy=arac.fiyat from arac where arac.model in (select MAX(arac.model) from arac)
end

select * from arac

-->Soru 7

create function aracbul(@nn int=0)
returns @geri table(marka varchar(25))
as 
	begin	
		insert into @geri (marka)
		select arac.marka from arac,alim,satis  where arac.aracno=@nn and (arac.aracno=satis.aracno or arac.aracno=alim.aracno) group by arac.marka
		return
	end

select * from aracbul(2)

-->Soru 8

create function satis_yap(@mno int, @ano int, @fyt money)
returns @tt table(mno int,aracno int,strh date,sfiyat money)
as 
	begin	
		
		insert into @tt values(@mno,@ano,GETDATE(),@fyt)
		
		return

	end



insert into satis(mno,aracno,strh,sfiyat) select * from satis_yap(2,3,5000)

-->Soru 9

create function ab(@nn int)
returns @geri table(marka varchar(25),an int)
as 
	begin	
		insert into @geri (marka,an)
		select arac.marka,arac.aracno from arac,satis where satis.aracno=arac.aracno and arac.aracno=@nn
		return
	end

declare @i int,@j int
set @i=0
select arac.aracno from arac
set @j=@@ROWCOUNT
while(@i<=@j)
 begin
  select * from ab(@i)
  set @i+=1
 end

 -->Soru 11

DECLARE @adi VARCHAR(50),@sadi varchar(25),@adres varchar(70),@tel varchar(20)

DECLARE musteriler CURSOR FOR
SELECT * from musteri order by madi

open musteriler

FETCH NEXT FROM musteriler INTO @adi,@sadi,@adres,@tel

WHILE @@FETCH_STATUS =0
 BEGIN
  SELECT * from musteri

 FETCH NEXT FROM musteriler INTO @adi,@sadi,@adres,@tel
 END

 -->Soru 12

Create trigger sts
on satis
for insert 
as 
 begin
  declare @yfyt money,@ano int,@fyt money
  select @ano=aracno,@yfyt=sfiyat from inserted
  select @fyt=fiyat from arac where arac.aracno=@ano
  if(@yfyt>@fyt)
   begin
    update arac set arac.fiyat=@yfyt where arac.aracno=@ano
   end
 end

insert into satis values(6,7,4,'15.06.2010',30000)